// Ten plik centralizuje wszystkie funkcje śledzenia dla Google Analytics 4.

/**
 * Główna funkcja wysyłająca zdarzenie do Google Analytics.
 * @param {string} eventName - Nazwa zdarzenia (np. 'search_city').
 * @param {object} eventParams - Dodatkowe parametry zdarzenia.
 */
function trackEvent(eventName, eventParams = {}) {
    if (typeof gtag === 'function') {
        gtag('event', eventName, eventParams);
        // Ten log zobaczysz tylko Ty w konsoli przeglądarki (F12) - potwierdzenie wysłania
        console.log(`[Analytics] Meldunek wysłany: ${eventName}`, eventParams);
    } else {
        console.warn('[Analytics] gtag() nie jest dostępne. Meldunek nie został wysłany.');
    }
}

// --- Funkcje-agenci do śledzenia konkretnych akcji ---

/**
 * Agent śledzący zapytania do AquaBota (NAJWAŻNIEJSZY).
 * @param {string} userQuery - Pytanie zadane przez użytkownika.
 */
export function trackBotQuery(userQuery) {
    trackEvent('ask_aquabot', {
        'bot_query': userQuery
    });
}

/**
 * Agent śledzący, kiedy użytkownik sprawdza jakość wody dla danego miasta.
 * @param {string} cityName - Nazwa wyszukiwanego miasta.
 */
export function trackCitySearch(cityName) {
    trackEvent('search_city', {
        'city_name': cityName
    });
}

/**
 * Agent śledzący, kiedy użytkownik znajduje najbliższą stację.
 * @param {string} cityName - Nazwa miasta.
 * @param {string} streetName - Nazwa ulicy.
 * @param {string} stationName - Nazwa znalezionej stacji.
 */
export function trackStationSearch(cityName, streetName, stationName) {
    trackEvent('search_station', {
        'city_name': cityName,
        'street_name': streetName,
        'station_found': stationName
    });
}

/**
 * Agent śledzący, kiedy użytkownik generuje ranking.
 * @param {string} rankingType - Typ rankingu ('city', 'suw', 'district').
 * @param {string} parameter - Parametr, dla którego generowany jest ranking.
 */
export function trackRankingGeneration(rankingType, parameter) {
    trackEvent('generate_ranking', {
        'ranking_type': rankingType,
        'ranking_parameter': parameter
    });
}
