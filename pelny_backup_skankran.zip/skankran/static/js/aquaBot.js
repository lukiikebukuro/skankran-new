/* globals gtag */

// Na samej górze pliku, obok innych importów:
import { trackBotQuery } from './analytics.js';

let stationContext = null;

export function startAquaBot(type) {
    const messagesContainer = document.getElementById(`aqua-bot-${type}-messages`);
    const inputField = document.getElementById(`aqua-bot-${type}-input`);
    const sendButton = document.getElementById(`aqua-bot-${type}-send`);

    if (!messagesContainer || !inputField || !sendButton) return;

    messagesContainer.innerHTML = ''; // Zawsze czyść widok na starcie

    const lastCheckedRaw = localStorage.getItem('lastCheckedStation');
    if (lastCheckedRaw) {
        try {
            stationContext = JSON.parse(lastCheckedRaw);
            initializeBotSession(stationContext, messagesContainer);
        } catch (e) {
            messagesContainer.innerHTML = '<div class="bot-message"><p>Błąd danych stacji. Wybierz ją ponownie.</p></div>';
        }
    } else {
        messagesContainer.innerHTML = '<div class="bot-message"><p>Cześć! Użyj sekcji "Znajdź stacje", abym wiedział, o czym rozmawiać.</p></div>';
    }

    sendButton.onclick = () => sendMessage(inputField, messagesContainer);
    inputField.onkeypress = (e) => {
        if (e.key === 'Enter') {
            e.preventDefault();
            sendMessage(inputField, messagesContainer);
        }
    };
}

async function initializeBotSession(context, messagesContainer) {
    messagesContainer.innerHTML = '<div class="bot-message"><p>Chwileczkę, łączę się z centralą...</p></div>';
    try {
        const response = await fetch('/aquabot/start', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ context: context })
        });
        if (!response.ok) throw new Error(`Błąd serwera: ${response.status}`);
        const data = await response.json();
        if (data.error) throw new Error(data.error);

        messagesContainer.innerHTML = '';
        appendBotMessage(data.reply, messagesContainer);
    } catch (error) {
        console.error('Błąd inicjalizacji sesji bota:', error);
        messagesContainer.innerHTML = `<div class="bot-message"><p>Nie udało się rozpocząć rozmowy. Błąd: ${error.message}</p></div>`;
    }
}

async function sendMessage(inputField, messagesContainer) {
    const userMessage = inputField.value.trim();
    if (!userMessage) return;

    // Agent melduje o każdym pytaniu do centrali
    trackBotQuery(userMessage);

    appendUserMessage(userMessage, messagesContainer);
    inputField.value = '';

    try {
        const response = await fetch('/aquabot/send', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ message: userMessage })
        });
        if (!response.ok) throw new Error(`Błąd serwera: ${response.status}`);
        const data = await response.json();
        if (data.error) throw new Error(data.error);

        appendBotMessage(data.reply, messagesContainer);

    } catch (error) {
        console.error('Błąd w sendMessage:', error);
        const errorReply = { text_message: "Ups, mam problem z połączeniem. Spróbuj zadać pytanie jeszcze raz." };
        appendBotMessage(errorReply, messagesContainer);
    }
}

function appendUserMessage(message, container) {
    const messageElement = document.createElement('div');
    messageElement.className = 'user-message';
    messageElement.innerHTML = `<p>${message}</p>`;
    container.appendChild(messageElement);
    container.scrollTop = container.scrollHeight;
}

function appendBotMessage(reply, container) {
    if (!reply) return;
    const messageElement = document.createElement('div');
    messageElement.className = 'bot-message';
    let replyHtml = '';

    if (reply.text_message) {
        replyHtml += `<p>${reply.text_message.replace(/\n/g, '<br>')}</p>`;
    }

    if (reply.parameters && reply.parameters.length > 0) {
        replyHtml += '<div><p>Parametry, na które warto zwrócić uwagę:</p><ul>';
        reply.parameters.forEach(param => {
            replyHtml += `<li><span class="dot ${param.color}"></span> ${param.name}: ${param.value}</li>`;
        });
        replyHtml += '</ul></div>';
    }

    // Usunięto stary, niepotrzebny kod śledzący gtag

    messageElement.innerHTML = replyHtml;
    container.appendChild(messageElement);
    container.scrollTop = container.scrollHeight;
}