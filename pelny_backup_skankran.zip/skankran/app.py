from dotenv import load_dotenv
import os
load_dotenv()

from flask import Flask, render_template, request, jsonify, session, redirect, url_for, flash
from datetime import timedelta
from aquabotBackend import AquaBot
from flask_sqlalchemy import SQLAlchemy
from flask_login import LoginManager, UserMixin, login_required, login_user, logout_user
from werkzeug.security import generate_password_hash, check_password_hash
from flask_session import Session

app = Flask(__name__)
# Standardowa konfiguracja
app.config['SECRET_KEY'] = os.getenv('SECRET_KEY', 'default_secret_key_zmien_to_w_produkcji')
app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///users.db'
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False

# Konfiguracja sesji po stronie serwera
app.config["SESSION_PERMANENT"] = False
app.config["SESSION_TYPE"] = "filesystem"
Session(app)

db = SQLAlchemy(app)
login_manager = LoginManager(app)
login_manager.login_view = 'login'

class User(db.Model, UserMixin):
    id = db.Column(db.Integer, primary_key=True)
    username = db.Column(db.String(80), unique=True, nullable=False)
    password = db.Column(db.String(120), nullable=False)
    is_premium = db.Column(db.Boolean, default=False)

@login_manager.user_loader
def load_user(user_id):
    return User.query.get(int(user_id))

@app.route('/')
def index():
    return render_template('index.html')

# --- NOWY KOD: NAPRAWA FORMULARZA FEEDBACK ---
@app.route('/send_feedback', methods=['POST'])
def send_feedback():
    """
    Ten endpoint odbiera wiadomości z formularza kontaktowego.
    """
    try:
        data = request.get_json()
        message = data.get('message')

        if not message:
            return jsonify({'error': 'Wiadomość nie może być pusta.'}), 400

        # Na razie, dla testów, drukujemy wiadomość w logach serwera.
        # To potwierdzi, że wiadomość dotarła.
        print("--- NOWA WIADOMOŚĆ FEEDBACK ---")
        print(message)
        print("-----------------------------")

        # Tutaj w przyszłości będzie kod wysyłający e-mail
        # np. przy użyciu SendGrid, Mailgun lub innej usługi.

        # Wysyłamy potwierdzenie do przeglądarki, że operacja się udała.
        return jsonify({'success': True})

    except Exception as e:
        print(f"[BŁĄD] Nie udało się przetworzyć wiadomości feedback: {e}")
        return jsonify({'error': 'Wystąpił błąd serwera.'}), 500
# ---------------------------------------------


# Reszta tras (rejestracja, logowanie, etc.)
@app.route('/register', methods=['GET', 'POST'])
def register():
    if request.method == 'POST':
        username = request.form['username']
        password = generate_password_hash(request.form['password'])
        new_user = User(username=username, password=password)
        try:
            db.session.add(new_user)
            db.session.commit()
            flash('Konto utworzone! Zaloguj się.')
            return redirect(url_for('login'))
        except:
            flash('Nazwa użytkownika zajęta.')
    return render_template('register.html')

@app.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        username = request.form['username']
        password = request.form['password']
        user = User.query.filter_by(username=username).first()
        if user and check_password_hash(user.password, password):
            login_user(user)
            return redirect(url_for('index'))
        else:
            flash('Błąd logowania.')
    return render_template('login.html')

@app.route('/logout')
@login_required
def logout():
    logout_user()
    session.clear()
    return redirect(url_for('index'))

@app.route('/feedback')
def feedback(): return render_template('feedback.html')
@app.route('/mission')
def mission(): return render_template('mission.html')
@app.route('/updates')
def updates(): return render_template('updates.html')
@app.route('/regulamin')
def regulamin(): return render_template('regulamin.html')
@app.route('/support')
def support(): return render_template('support.html')


# Logika bota
@app.route('/aquabot/start', methods=['POST'])
def aquabot_start():
    bot = AquaBot()
    data = request.get_json()
    user_context = data.get('context')
    if not user_context or 'station' not in user_context or 'city' not in user_context:
        return jsonify({'error': 'Brak wymaganego kontekstu stacji.'}), 400
    try:
        bot.set_station_context(user_context)
        initial_response = bot.get_initial_greeting()
        return jsonify({'reply': initial_response})
    except Exception as e:
        print(f"[BŁĄD KRYTYCZNY w aquabot_start]: {e}")
        return jsonify({'error': str(e)}), 500

@app.route('/aquabot/send', methods=['POST'])
def aquabot_send():
    bot = AquaBot()
    data = request.get_json()
    user_message = data.get('message', '')
    if not user_message:
        return jsonify({'error': 'Brak wiadomości.'}), 400
    try:
        reply = bot.get_bot_response(user_message)
        return jsonify({'reply': reply})
    except Exception as e:
        print(f"[BŁĄD KRYTYCZNY w aquabot_send]: {e}")
        return jsonify({'error': str(e)}), 500

if __name__ == '__main__':
    with app.app_context():
        db.create_all()
    app.run(debug=True, port=5000)
