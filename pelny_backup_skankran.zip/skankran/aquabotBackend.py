# aquabotBackend.py - WERSJA HYBRYDOWA ("Smooth" + "Biblia Bota" + Sondy Wywiadowcze)

import json
import os
import google.generativeai as genai
from flask import session

# Dynamiczne ścieżki do plików, które działają wszędzie
try:
    BASE_DIR = os.path.dirname(os.path.abspath(__file__))
    WATER_ANALYSIS_PATH = os.path.join(BASE_DIR, 'waterAnalysis.json')
    AVERAGES_PATH = os.path.join(BASE_DIR, 'averages.json')
    ADVICE_TEMPLATES_PATH = os.path.join(BASE_DIR, 'advice_templates.json')
except NameError:
    WATER_ANALYSIS_PATH = 'waterAnalysis.json'
    AVERAGES_PATH = 'averages.json'
    ADVICE_TEMPLATES_PATH = 'advice_templates.json'

try:
    # Inicjalizacja modelu Gemini
    genai.configure(api_key="AIzaSyAtlxvm1L9cma4Q79mbLfKyOvbjQUthGxQ")
    model = genai.GenerativeModel('gemini-2.5-pro')
except Exception as e:
    print(f"[CRITICAL ERROR] Gemini API configuration failed: {e}")
    model = None

def parseFloat(value):
    """Funkcja pomocnicza do parsowania liczb, obsługująca znaki '<'."""
    if isinstance(value, str) and value.startswith('<'):
        try:
            return float(value.replace('<', '').strip())
        except (ValueError, TypeError):
            return None
    try:
        return float(value)
    except (ValueError, TypeError):
        return None

class AquaBot:
    def __init__(self):
        """Inicjalizuje bota, ładując wszystkie pliki danych jako atrybuty klasy."""
        try:
            with open(WATER_ANALYSIS_PATH, 'r', encoding='utf-8') as f:
                self.full_water_data = json.load(f)
        except Exception as e:
            print(f"[ERROR] Could not load waterAnalysis.json: {e}")
            self.full_water_data = {}

        try:
            with open(AVERAGES_PATH, 'r', encoding='utf-8') as f:
                self.city_averages = json.load(f)
        except Exception as e:
            print(f"[ERROR] Could not load averages.json: {e}")
            self.city_averages = {}

        # Ładujemy "Biblię Bota"
        try:
            with open(ADVICE_TEMPLATES_PATH, 'r', encoding='utf-8') as f:
                self.advice_templates = json.load(f)
                print("[DEBUG] Advice templates (Biblia Bota) loaded successfully.")
        except Exception as e:
            print(f"[WARNING] Could not load advice_templates.json: {e}. Bot will rely solely on AI.")
            self.advice_templates = {}

        self.param_map = {
            'twardość': 'twardosc', 'twardosci': 'twardosc', 'skórę': 'twardosc', 'skore': 'twardosc',
            'azotanów': 'azotany', 'azotany': 'azotany',
            'żelaza': 'zelazo', 'zelazo': 'zelazo',
            'fluorków': 'fluorki', 'fluorki': 'fluorki',
            'chloru': 'chlor', 'chlor': 'chlor',
            'manganu': 'mangan', 'mangan': 'mangan',
            'ph': 'ph'
        }
        self.thresholds = {'ph': {'red_low': 6.5, 'orange_low': 7.0, 'orange_high': 8.5, 'red_high': 9.5}, 'twardosc': {'red': 220, 'orange': 150}, 'azotany': {'red': 20, 'orange': 10}, 'zelazo': {'red': 0.2, 'orange': 0.1}, 'fluorki': {'red': 1.5, 'orange': 1.2}, 'chlor': {'red': 0.27, 'orange': 0.15}, 'mangan': {'red': 50, 'orange': 20}}

    def _get_color(self, parameter, value):
        # ... (ta funkcja pozostaje bez zmian)
        param_lower = parameter.lower()
        if value is None or value == "Brak danych" or value == "": return 'grey-dot'
        num_value = parseFloat(value)
        if num_value is None: return 'grey-dot'
        if num_value == 0:
            user_context = session.get('user_context', {}); city_name = user_context.get('city', '')
            if city_name.lower() == 'poznań' and param_lower in ['olow', 'rtec']: return 'green-dot'
            return 'grey-dot'
        rules = self.thresholds.get(param_lower)
        if rules:
            if param_lower == 'ph':
                if num_value < rules['red_low'] or num_value > rules['red_high']: return 'red-dot'
                if num_value < rules['orange_low'] or num_value > rules['orange_high']: return 'orange-dot'
            else:
                if 'red' in rules and num_value > rules['red']: return 'red-dot'
                if 'orange' in rules and num_value > rules['orange']: return 'orange-dot'
        return 'green-dot'

    def set_station_context(self, context):
        # ... (ta funkcja pozostaje bez zmian)
        city_name = context.get('city')
        if city_name and self.full_water_data.get(city_name):
            session['user_context'] = context; session['chat_history'] = []; session.modified = True
            print(f"[DEBUG] Context set for city: {city_name}.")
        else:
            print(f"[ERROR] Data not found for city: {city_name}")

    def get_initial_greeting(self):
        # ... (ta funkcja pozostaje bez zmian)
        if 'user_context' not in session: return {'text_message': 'Error: Station context not set.'}
        all_params = self.get_colored_params()
        params_with_issues = [p for p in all_params if p['color'] in ['red-dot', 'orange-dot']]
        param_summary = ", ".join([f"{p['name']} ({p['value']})" for p in params_with_issues])
        if not param_summary: param_summary = "Wszystkie kluczowe parametry są w normie."
        city = session['user_context']['city']
        system_prompt = f"""Jesteś AquaBotem. Przywitaj użytkownika z miasta {city}. Zwięźle poinformuj go o podwyższonych parametrach: {param_summary}. ZAWSZE zakończ pytaniem: "Chcesz porozmawiać o tym, jak te wartości mogą wpływać na Twoje zdrowie, urodę, czy codzienne życie?" """
        response = model.generate_content(system_prompt)
        bot_message = response.text
        session.setdefault('chat_history', []).append({'role': 'model', 'parts': [bot_message]})
        session.modified = True
        return {'text_message': bot_message, "parameters": params_with_issues}

    def get_colored_params(self):
        # ... (ta funkcja pozostaje bez zmian)
        station_data = session.get('user_context', {}).get('station', {}).get('data', {})
        params_with_colors = []
        for param, value in station_data.items():
            color = self._get_color(param, value)
            params_with_colors.append({'name': param.capitalize(), 'value': str(value), 'color': color})
        return params_with_colors

    def get_bot_response(self, user_message):
        """Generuje odpowiedź bota i dodaje dane wywiadowcze do śledzenia."""
        if not model:
            return {'text_message': "Critical Error: API Model not loaded."}
        if 'user_context' not in session:
            return {'text_message': 'Proszę, najpierw wybierz stację na mapie.'}

        session.setdefault('chat_history', []).append({'role': 'user', 'parts': [user_message]})

        city_data_for_prompt = self.full_water_data.get(session['user_context']['city'], {})
        averages_for_prompt = self.city_averages

        system_prompt = f"""
        Jesteś AquaBotem, ekspertem od jakości wody.
        TWOJE DYREKTYWY: Bądź zwięzły. Używaj wypunktowań. ZAWSZE jasno określaj, czy mówisz o danych ze stacji (wymień jej nazwę) czy o średniej dla miasta. Twoim głównym zadaniem jest znalezienie odpowiedzi w BAZIE WIEDZY i przedstawienie jej w naturalny, konwersacyjny sposób.

        KONTEKST:
        A. Lokalizacja: Stacja {session['user_context']['station']['name']} w {session['user_context']['city']}.
        B. Dane Miasta: {json.dumps(city_data_for_prompt, indent=2, ensure_ascii=False)}
        C. Dane Średnie: {json.dumps(averages_for_prompt, indent=2, ensure_ascii=False)}
        D. BAZA WIEDZY (ADVICE TEMPLATES):
           ```json
           {json.dumps(self.advice_templates, indent=2, ensure_ascii=False)}
           ```

        HISTORIA ROZMOWY:
        {json.dumps(session.get('chat_history', []), indent=2, ensure_ascii=False)}

        NAJNOWSZA WIADOMOŚĆ: "{user_message}"

        TWOJE ZADANIE: Odpowiedz precyzyjnie, bazując na powyższym kontekście, ze szczególnym uwzględnieniem BAZY WIEDZY.
        """

        try:
            chat = model.start_chat(history=session['chat_history'][:-1])
            response = chat.send_message(system_prompt)
            bot_response_text = response.text
            session['chat_history'].append({'role': 'model', 'parts': [bot_response_text]})
            session.modified = True

            # --- PRZYGOTOWANIE ŁADUNKU WYWIADOWCZEGO ---
            user_context = session.get('user_context', {})
            tracking_data = {
                'query_text': user_message,
                'city': user_context.get('city', 'unknown'),
                'station_name': user_context.get('station', {}).get('name', 'unknown')
            }

            comparison_data = None
            cities_in_response = [city for city in self.city_averages.keys() if city in bot_response_text]
            if len(cities_in_response) >= 2:
                comparison_data = {
                    'city_1': cities_in_response[0],
                    'city_2': cities_in_response[1]
                }
            # ---------------------------------------------

            return {
                'text_message': bot_response_text,
                'tracking_data': tracking_data,
                'comparison_data': comparison_data
            }

        except Exception as e:
            print(f"API ERROR: {e}")
            session.get('chat_history', []).pop()
            session.modified = True
            return {'text_message': "Chwilowa awaria połączenia z moją inteligencją. Spróbuj zadać pytanie jeszcze raz!"}
